import requests
import json
import os

# ElasticSearch Entry
HEADERS = {"Content-Type": "application/json"}
URL = "http://" + os.environ["es_host"] + ":" + os.environ["es_post"]
URL = URL + "/" + os.environ["index"] + "/" + os.environ["doc_type"] + "/" + os.environ["document"]

def lambda_handler(event, context):
    # TODO implement
    for record in event['Records']:
        #データ取得
        tm = record['dynamodb']['NewImage']['GetDateTime']['S']
        tmp = record['dynamodb']['NewImage']['Temperature']['N']
        hum = record['dynamodb']['NewImage']['Humidity']['N']
        data={"GetDateTime":tm,"Humidity":hum,"Temperature":tmp}
        print(data)

        #lineに通知
        r = requests.put(URL , headers=HEADERS, json=data)
    es.close()
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

# Local Execute
testdata = {"Records":[{"dynamodb":{"NewImage":{"GetDateTime":{"S":"2021-11-03 16:20:18"},"Temperature":{"N":"20.5"},"Humidity":{"N":"72.3"}}}}]}
lambda_handler(testdata,"")
