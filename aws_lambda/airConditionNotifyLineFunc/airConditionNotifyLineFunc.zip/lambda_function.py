import os
import requests

# Line Notify
ACCESS_TOKEN = os.environ["access_token"]
HEADERS = {"Authorization": "Bearer %s" % ACCESS_TOKEN,"Content-Type": "application/json"}
URL = "https://api.line.me/v2/bot/message/broadcast"

def lambda_handler(event, context):
    tmp = record['dynamodb']['NewImage']['Temperature']['N']
    hum = record['dynamodb']['NewImage']['Humidity']['N']
    data = {"messages": [{"type":"text","text":"気温 %f℃、湿度 %f％" % (tmp ,hum)}]}
    #lineに通知
    r = requests.post(URL, headers=HEADERS, json=data)
    print(r)
